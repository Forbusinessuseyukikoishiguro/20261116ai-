# 演習（すべて、講座の kit で実際に動くことを確かめた手順）

## E1 最初の試験（セクション2）
- 手順：kit フォルダで `npm test`
- できた！：`# pass 13`、`# fail 0`

## E2 仕様を書く（セクション3）
- 手順：次の依頼を、5つの問いで答え、FR・AC の表にする。依頼：「ファイルを選んだら、すぐ文字にしたい」
- できた！：番号（FR-xx）、受け入れ基準（入力・結果・判定）、状態が書けている

## E3 色を変える（セクション4）
- 手順：style.css の `--accent` を `#b35c00` に変え、画面を開き直す。元に戻す
- できた！：ボタンの色が変わり、元に戻せた

## E4 上限を変えて、試験を読む（セクション5）
- 手順：lib.test.js の W-01 にある 2 つ目の確認（`f("a.wav", 25 * L.MB, "audio/wav"), 25`）の、最後の `25` を `10` に変える。`node --test test/lib.test.js` を実行。元に戻す
- できた！：W-01 が落ちる（25 MB のファイルは 10 MB の上限を超えるため）。理由を説明できる

## E5 練習の窓口で、キーを確かめる（セクション7）
- 手順：`PORT=8790 node server/mock-whisper-server.js` を起動。キー付きとキーなしで、次の2つを送る

```bash
curl -s -o /dev/null -w "%{http_code}\n" -X POST http://localhost:8790/v1/audio/transcriptions -H "Authorization: Bearer test-key" -F "file=@/dev/null;filename=a.wav" -F "model=whisper-1"
curl -s -o /dev/null -w "%{http_code}\n" -X POST http://localhost:8790/v1/audio/transcriptions -F "file=@/dev/null;filename=a.wav" -F "model=whisper-1"
```

- できた！：1行目は 200、2行目は 401

## E6 テストを1つ追加する（セクション8）
- 手順：lib.test.js の末尾に、次の試験を追加する（名前は W-08）。`npm test` を実行する

```javascript
test("W-08 checkFile：拡張子だけで、音声と判断する（type が空でも受け付ける）", () => {
  assert.equal(L.checkFile({ name: "a.m4a", size: 1000, type: "" }, 25).ok, true);
});
```

- できた！：`# tests 14`、`# pass 14`、`# fail 0`
