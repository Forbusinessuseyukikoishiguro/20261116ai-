/* lib.test.js — 計算の部分の試験（node --test で実行）。画面は使わない。 */
const test = require("node:test");
const assert = require("node:assert/strict");
const L = require("../web/lib.js");

const f = (name, size, type) => ({ name, size, type });

test("W-01 checkFile：25 MB 以下の音声は受け付ける", () => {
  assert.equal(L.checkFile(f("a.mp3", 1000, "audio/mpeg"), 25).ok, true);
  assert.equal(L.checkFile(f("a.wav", 25 * L.MB, "audio/wav"), 25).ok, true);
});

test("W-02 checkFile：25 MB を超えると、送る前に止める（理由に MB を含む）", () => {
  const r = L.checkFile(f("a.wav", 26 * L.MB, "audio/wav"), 25);
  assert.equal(r.ok, false);
  assert.match(r.reason, /26\.0 MB/);
});

test("W-03 checkFile：空のファイルと、音声でないファイルを止める", () => {
  assert.equal(L.checkFile(f("a.mp3", 0, "audio/mpeg"), 25).ok, false);
  assert.equal(L.checkFile(f("memo.txt", 100, "text/plain"), 25).ok, false);
  assert.equal(L.checkFile(null, 25).ok, false);
});

test("W-04 checkConfig：endpoint が URL でなければ送らない", () => {
  assert.equal(L.checkConfig({ endpoint: "localhost:8790", model: "whisper-1" }).ok, false);
  assert.equal(L.checkConfig({ endpoint: "http://localhost:8790", model: "whisper-1" }).ok, true);
  assert.equal(L.checkConfig({ endpoint: "http://localhost:8790", model: "" }).ok, false);
});

test("W-05 explainStatus：401・429・5xx で、次の行動が分かる文になる", () => {
  assert.match(L.explainStatus(401), /APIキー/);
  assert.match(L.explainStatus(429), /時間をおいて/);
  assert.match(L.explainStatus(503), /障害/);
});

test("W-06 isRetryable：通信の失敗、429、5xx だけ再試行する。401 や 400 は再試行しない", () => {
  assert.equal(L.isRetryable(new TypeError("fetch failed")), true);
  assert.equal(L.isRetryable({ status: 429 }), true);
  assert.equal(L.isRetryable({ status: 500 }), true);
  assert.equal(L.isRetryable({ status: 401 }), false);
  assert.equal(L.isRetryable({ status: 400 }), false);
  assert.equal(L.isRetryable({ name: "AbortError" }), false);
});

test("W-07 saveName：拡張子を .txt に変える（元の名前が無ければ transcript.txt）", () => {
  assert.equal(L.saveName("会議.mp3"), "会議.txt");
  assert.equal(L.saveName("a.b.wav"), "a.b.txt");
  assert.equal(L.saveName(""), "transcript.txt");
});
