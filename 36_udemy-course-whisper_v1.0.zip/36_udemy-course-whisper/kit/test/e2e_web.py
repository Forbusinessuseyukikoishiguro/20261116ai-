#!/usr/bin/env python3
"""e2e_web.py — 画面の試験（実ブラウザ）。模倣サーバーに送り、結果と案内を確かめる。
実行：python3 test/e2e_web.py   （pip install playwright、python -m playwright install chromium が必要）"""
import functools, http.server, os, subprocess, sys, tempfile, threading, time, socket, shutil
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
WEB = os.path.join(ROOT, "web")
PORT_MOCK, PORT_WEB = 8790, 8791
results = []

def check(name, ok, detail=""):
    results.append(ok); print(f"[{'合' if ok else '否'}] {name} {'' if ok else detail}", flush=True)

def wait_port(port, open_=True, t=10):
    end = time.time() + t
    while time.time() < end:
        with socket.socket() as s:
            s.settimeout(0.3)
            if (s.connect_ex(("127.0.0.1", port)) == 0) == open_: return True
        time.sleep(0.2)
    return False

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a): pass

def main():
    tmp = tempfile.mkdtemp()
    shutil.copytree(WEB, os.path.join(tmp, "web"))
    cfg = os.path.join(tmp, "web", "config.js")
    def write_config(key):
        with open(cfg, "w", encoding="utf-8") as f:
            f.write("window.WHISPER_CONFIG = Object.freeze({endpoint:'http://127.0.0.1:%d', apiKey:'%s', model:'whisper-1', maxFileMB:25, timeoutMs:20000});" % (PORT_MOCK, key))
    audio = os.path.join(tmp, "会議.wav")
    with open(audio, "wb") as f: f.write(b"RIFF" + b"\0" * 2000)
    big = os.path.join(tmp, "big.wav")
    with open(big, "wb") as f: f.truncate(26 * 1024 * 1024)

    mock = subprocess.Popen(["node", os.path.join(ROOT, "server", "mock-whisper-server.js")],
                            env=dict(os.environ, PORT=str(PORT_MOCK)), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    web = http.server.ThreadingHTTPServer(("127.0.0.1", PORT_WEB), functools.partial(Quiet, directory=os.path.join(tmp, "web")))
    threading.Thread(target=web.serve_forever, daemon=True).start()
    try:
        wait_port(PORT_MOCK, True)
        with sync_playwright() as p:
            b = p.chromium.launch(); pg = b.new_page()
            errs = []; pg.on("pageerror", lambda e: errs.append(str(e)))
            write_config("test-key")
            pg.goto(f"http://127.0.0.1:{PORT_WEB}/index.html")
            check("起動時は、run ボタンが押せない（ファイル未選択）", pg.is_disabled("#run"))
            pg.set_input_files("#file", audio)
            check("音声を選ぶと、run ボタンが押せる", pg.is_enabled("#run"))
            pg.click("#run")
            pg.wait_for_function("document.getElementById('status').textContent.includes('完了')", timeout=20000)
            out = pg.inner_text("#result")
            check("結果欄に、模倣サーバーの文字が出る", "【モック】" in out and "会議.wav" in out, out[:80])
            check("コピーと保存が押せる", pg.is_enabled("#copy") and pg.is_enabled("#save"))
            pg.set_input_files("#file", big)
            check("25 MB を超えるファイルは、送る前に止める", pg.is_disabled("#run") and "大きすぎ" in pg.inner_text("#error"), pg.inner_text("#error"))
            write_config("wrong")
            pg.goto(f"http://127.0.0.1:{PORT_WEB}/index.html")
            pg.set_input_files("#file", audio)
            pg.click("#run")
            pg.wait_for_function("document.getElementById('error').hidden === false", timeout=20000)
            check("キーが違うと、APIキーの案内が出る（401）", "APIキー" in pg.inner_text("#error"), pg.inner_text("#error"))
            check("ページに未処理の例外がない", not errs, "; ".join(errs))
            b.close()
    finally:
        mock.terminate(); mock.wait(timeout=5)
        web.shutdown(); web.server_close()
    fails = results.count(False)
    print(f"\n== 結果：合格 {len(results)-fails} / {len(results)} ==")
    sys.exit(1 if fails else 0)

if __name__ == "__main__":
    main()
