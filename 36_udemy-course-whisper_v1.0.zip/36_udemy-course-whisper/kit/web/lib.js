/* lib.js — 計算の部分（画面に触らない）。テストは node で行う。
 * 画面では window.WhisperLib として使い、テストでは require で読む。 */
(function (root) {
  "use strict";

  const MB = 1024 * 1024;

  /** 音声ファイルの検査。問題があれば理由を返す（送信の前に止める） */
  function checkFile(file, maxMB) {
    if (!file) return { ok: false, reason: "音声ファイルを選んでください。" };
    if (file.size === 0) return { ok: false, reason: "空のファイルです。別のファイルを選んでください。" };
    if (file.size > maxMB * MB) {
      return { ok: false, reason: `ファイルが大きすぎます（${(file.size / MB).toFixed(1)} MB）。${maxMB} MB 以下に分割してください。` };
    }
    const okType = (file.type || "").startsWith("audio/") || /\.(mp3|m4a|wav|webm|mp4|mpeg|mpga)$/i.test(file.name || "");
    if (!okType) return { ok: false, reason: "音声ファイルではないようです（mp3、m4a、wav、webm など）。" };
    return { ok: true };
  }

  /** 設定の検査。endpoint が http(s) の URL でなければ送らない */
  function checkConfig(cfg) {
    if (!cfg || typeof cfg.endpoint !== "string" || !/^https?:\/\//.test(cfg.endpoint)) {
      return { ok: false, reason: "config.js の endpoint が正しくありません（http:// か https:// で始まる URL）。" };
    }
    if (!cfg.model) return { ok: false, reason: "config.js の model を入れてください。" };
    return { ok: true };
  }

  /** HTTP の状態に応じた、利用者向けの案内 */
  function explainStatus(status) {
    if (status === 401 || status === 403) return "APIキーが正しくありません。config.js の apiKey を確かめてください。";
    if (status === 400) return "送った内容が正しくありません。音声ファイルの形式を確かめてください。";
    if (status === 413) return "ファイルが大きすぎます。分割してから、もう一度送ってください。";
    if (status === 429) return "利用の上限に達しました。少し時間をおいて、もう一度お試しください。";
    if (status >= 500) return `サーバーで障害が起きました（${status}）。時間をおいて、もう一度お試しください。`;
    return `予期しないエラーです（${status}）。`;
  }

  /** 失敗の種類ごとの案内（例外の種類と HTTP の状態から） */
  function explainError(err) {
    if (err && err.name === "AbortError") return "時間内に応答がありませんでした。音声を短くして、もう一度お試しください。";
    if (err && err.name === "TypeError") return "接続できません。endpoint とネットワークを確かめてください。";
    if (err && typeof err.status === "number") return explainStatus(err.status);
    return "予期しないエラーが起きました。";
  }

  /** 再試行してよい失敗か（一時的な失敗だけ。401 や 400 は再試行しない） */
  function isRetryable(err) {
    if (!err) return false;
    if (err.name === "AbortError") return false;
    if (err.name === "TypeError") return true;
    return err.status === 429 || (typeof err.status === "number" && err.status >= 500);
  }

  /** 保存するファイル名（元の名前の拡張子を .txt に変える） */
  function saveName(original) {
    const base = String(original || "").replace(/\.[^./\\]+$/, "");
    return (base || "transcript") + ".txt";
  }

  const api = { MB, checkFile, checkConfig, explainStatus, explainError, isRetryable, saveName };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.WhisperLib = api;
})(typeof window !== "undefined" ? window : globalThis);
