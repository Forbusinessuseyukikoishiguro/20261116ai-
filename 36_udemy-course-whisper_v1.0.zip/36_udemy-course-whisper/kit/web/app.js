/* app.js — 画面の制御。送信・表示・保存だけを行う。計算は lib.js。 */
(function () {
  "use strict";
  const L = window.WhisperLib;
  const cfg = Object.assign({ endpoint: "http://localhost:8790", apiKey: "", model: "whisper-1", maxFileMB: 25, timeoutMs: 120000 }, window.WHISPER_CONFIG || {});
  const $ = (id) => document.getElementById(id);
  const ui = { file: $("file"), info: $("fileInfo"), run: $("run"), status: $("status"), error: $("error"), result: $("result"), copy: $("copy"), save: $("save") };
  let chosen = null;
  let text = "";

  function showError(msg) { ui.error.textContent = msg; ui.error.hidden = !msg; }
  function setStatus(msg) { ui.status.textContent = msg; }

  ui.file.addEventListener("change", () => {
    chosen = ui.file.files[0] || null;
    showError("");
    text = "";
    ui.result.textContent = "（ここに文字が出ます）";
    ui.copy.disabled = true; ui.save.disabled = true;
    if (!chosen) { ui.info.textContent = "まだ選んでいません"; ui.run.disabled = true; return; }
    const mb = (chosen.size / L.MB).toFixed(1);
    ui.info.textContent = `${chosen.name}（${mb} MB）`;
    const check = L.checkFile(chosen, cfg.maxFileMB);
    if (!check.ok) { showError(check.reason); ui.run.disabled = true; return; }
    ui.run.disabled = false;
  });

  async function transcribe(file) {
    const form = new FormData();
    form.append("file", file, file.name);      // 音声ファイル（項目名は file）
    form.append("model", cfg.model);           // モデル名（項目名は model）
    const headers = {};
    if (cfg.apiKey) headers.Authorization = `Bearer ${cfg.apiKey}`;
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), cfg.timeoutMs);
    try {
      const res = await fetch(`${cfg.endpoint.replace(/\/+$/, "")}/v1/audio/transcriptions`, {
        method: "POST", headers, body: form, signal: ctl.signal,
      });
      if (!res.ok) throw Object.assign(new Error("http"), { status: res.status });
      const data = await res.json();
      if (!data || typeof data.text !== "string") throw new Error("bad response");
      return data.text;
    } finally {
      clearTimeout(timer);
    }
  }

  ui.run.addEventListener("click", async () => {
    const cfgCheck = L.checkConfig(cfg);
    if (!cfgCheck.ok) { showError(cfgCheck.reason); return; }
    if (!chosen) return;
    ui.run.disabled = true; showError(""); setStatus("文字起こし中です…");
    try {
      text = await transcribe(chosen);
      ui.result.textContent = text || "（認識結果は空でした）";
      ui.copy.disabled = false; ui.save.disabled = false;
      setStatus("完了しました。");
    } catch (err) {
      ui.result.textContent = "文字起こしできませんでした。";
      setStatus("");
      showError(L.explainError(err));
    } finally {
      ui.run.disabled = false;
    }
  });

  ui.copy.addEventListener("click", async () => {
    try { await navigator.clipboard.writeText(text); setStatus("コピーしました。"); }
    catch { showError("コピーできませんでした。結果を選んで、手動でコピーしてください。"); }
  });

  ui.save.addEventListener("click", () => {
    const blob = new Blob(["\uFEFF" + text], { type: "text/plain;charset=utf-8" });   // BOM 付き（メモ帳で文字化けしない）
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = L.saveName(chosen && chosen.name);
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
})();
